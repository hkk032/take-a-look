<?php
$con = mysqli_connect("localhost", "root", "mysql", "lifestylestore")or die($mysqli_error($con));
session_start();
